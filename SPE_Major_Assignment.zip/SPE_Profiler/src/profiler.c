/*
 * profiler.c - implementation of the instrumentation profiler
 *
 * Idea: the profiler keeps its own copy of the call stack. Each stack frame
 * remembers which *call path* it belongs to (main -> f1 -> square is a
 * different path from main -> square, even though both end in square).
 * Paths are stored as a tree: a path is its parent path plus one function,
 * so finding the path for a new call only means looking at the children of
 * the caller's path.
 *
 * For every path we count how many times it was executed and add up:
 *   inclusive time = time from entering the function to leaving it,
 *                    including everything it called
 *   exclusive time = inclusive time minus the time spent in the functions it
 *                    called, i.e. the time spent in its own code
 */

#if !defined(_WIN32) && !defined(_POSIX_C_SOURCE)
#define _POSIX_C_SOURCE 199309L      /* for clock_gettime() */
#endif

#include "profiler.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#endif

/* ------------------------------------------------------------------ */
/* data structures                                                     */
/* ------------------------------------------------------------------ */

typedef struct {
    int         parent;              /* parent path index, -1 for a top-level path */
    const char *func;                /* last function on this path                 */
    int         depth;               /* 0 for main                                 */
    char        text[PROF_PATH_LEN]; /* "main -> f1 -> square"                     */
    long        count;               /* how many times this path was executed      */
    double      incl_us;             /* total inclusive time (microseconds)        */
    double      excl_us;             /* total exclusive time (microseconds)        */
} PathRecord;

typedef struct {
    const char *caller;
    const char *callee;
    long        count;
} CallPair;

typedef struct {
    const char *name;
    long        calls;
    double      incl_us;
    double      excl_us;
} FuncRecord;

typedef struct {
    const char *func;
    int         path;                /* index into paths[]                          */
    double      t_enter;             /* time the function body started             */
    double      child_us;            /* time spent in instrumented callees so far   */
} Frame;

static struct {
    int        on;
    double     t0;                   /* time of profiler_init()                     */
    double     t_end;

    Frame      stack[PROF_MAX_DEPTH];
    int        sp;                   /* number of frames on the stack               */
    int        too_deep;             /* calls ignored because the stack was full    */

    PathRecord paths[PROF_MAX_PATHS];
    int        n_paths;
    CallPair   pairs[PROF_MAX_PAIRS];
    int        n_pairs;
    FuncRecord funcs[PROF_MAX_FUNCS];
    int        n_funcs;

    double     overhead_us;          /* time spent inside the profiler itself       */
    long       n_events;             /* CALL + RETURN events written                */
    long       n_calls;
    int        n_warnings;
    int        full_warned;

    FILE      *f_events;
    FILE      *f_trace;
} P;

/* ------------------------------------------------------------------ */
/* timer: microseconds since profiler_init()                           */
/* clock() only ticks every ~1 ms on Windows, which is why the old     */
/* version printed 0.000 / 1.000 ms for everything.                    */
/* ------------------------------------------------------------------ */

static double raw_us(void)
{
#ifdef _WIN32
    static LARGE_INTEGER freq;
    LARGE_INTEGER c;
    if (freq.QuadPart == 0)
        QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart * 1e6 / (double)freq.QuadPart;
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1e6 + (double)ts.tv_nsec / 1e3;
#endif
}

static double now_us(void) { return raw_us() - P.t0; }

/* ------------------------------------------------------------------ */
/* small helpers                                                       */
/* ------------------------------------------------------------------ */

static void warn(const char *msg, const char *a, const char *b)
{
    P.n_warnings++;
    fprintf(stderr, "[Profiler] warning: ");
    fprintf(stderr, msg, a, b);
    fprintf(stderr, "\n");
    if (P.f_events) {
        fprintf(P.f_events, "             !! WARNING: ");
        fprintf(P.f_events, msg, a, b);
        fprintf(P.f_events, "\n");
    }
}

static void table_full(const char *what)
{
    if (!P.full_warned) {
        warn("%s table is full, raise the limit in profiler.h%s", what, "");
        P.full_warned = 1;
    }
}

/* find the path "parent path + func", creating it the first time */
static int path_get(int parent, const char *func)
{
    int i;
    for (i = 0; i < P.n_paths; i++)
        if (P.paths[i].parent == parent && strcmp(P.paths[i].func, func) == 0)
            return i;

    if (P.n_paths >= PROF_MAX_PATHS) {
        table_full("path");
        return -1;
    }

    PathRecord *p = &P.paths[P.n_paths];
    memset(p, 0, sizeof *p);
    p->parent = parent;
    p->func   = func;
    if (parent < 0) {
        p->depth = 0;
        snprintf(p->text, sizeof p->text, "%s", func);
    } else {
        p->depth = P.paths[parent].depth + 1;
        /* text = parent's text + " -> " + func, cut off if it gets too long */
        size_t cap = sizeof p->text;
        strcpy(p->text, P.paths[parent].text);
        strncat(p->text, " -> ", cap - 1 - strlen(p->text));
        strncat(p->text, func,   cap - 1 - strlen(p->text));
    }
    return P.n_paths++;
}

static void pair_add(const char *caller, const char *callee)
{
    int i;
    for (i = 0; i < P.n_pairs; i++)
        if (strcmp(P.pairs[i].caller, caller) == 0 &&
            strcmp(P.pairs[i].callee, callee) == 0) {
            P.pairs[i].count++;
            return;
        }
    if (P.n_pairs >= PROF_MAX_PAIRS) { table_full("caller/callee"); return; }
    P.pairs[P.n_pairs].caller = caller;
    P.pairs[P.n_pairs].callee = callee;
    P.pairs[P.n_pairs].count  = 1;
    P.n_pairs++;
}

static FuncRecord *func_get(const char *name)
{
    int i;
    for (i = 0; i < P.n_funcs; i++)
        if (strcmp(P.funcs[i].name, name) == 0)
            return &P.funcs[i];
    if (P.n_funcs >= PROF_MAX_FUNCS) { table_full("function"); return NULL; }
    memset(&P.funcs[P.n_funcs], 0, sizeof P.funcs[0]);
    P.funcs[P.n_funcs].name = name;
    return &P.funcs[P.n_funcs++];
}

static void indent(FILE *f, int n)
{
    while (n-- > 0) fputs("  ", f);
}

/* take the top frame off the stack at time t and record its times */
static void pop_frame(double t)
{
    Frame *fr = &P.stack[P.sp - 1];
    double incl = t - fr->t_enter;
    double excl = incl - fr->child_us;
    const char *ret_to = (P.sp > 1) ? P.stack[P.sp - 2].func : "ROOT";

    if (fr->path >= 0) {
        P.paths[fr->path].incl_us += incl;
        P.paths[fr->path].excl_us += excl;
    }
    FuncRecord *fn = func_get(fr->func);
    if (fn) { fn->incl_us += incl; fn->excl_us += excl; }

    indent(P.f_trace, P.sp - 1);
    fprintf(P.f_trace, "<- EXIT  %s()  incl %.2f us, excl %.2f us\n",
            fr->func, incl, excl);
    fprintf(P.f_events, "[%12.2f us] RETURN %-13s <- %-13s incl %9.2f us  excl %9.2f us\n",
            t, ret_to, fr->func, incl, excl);
    P.n_events++;

    P.sp--;
    if (P.sp > 0)
        P.stack[P.sp - 1].child_us += incl;
}

/* ------------------------------------------------------------------ */
/* public functions                                                    */
/* ------------------------------------------------------------------ */

void profiler_init(void)
{
    if (P.on) return;
    memset(&P, 0, sizeof P);

    P.f_events = fopen("event_log.txt", "w");
    P.f_trace  = fopen("call_trace.txt", "w");
    if (!P.f_events || !P.f_trace) {
        fprintf(stderr, "[Profiler] could not open output files\n");
        exit(1);
    }

    fprintf(P.f_events,
        "EVENT LOG\n"
        "=========\n"
        "One line per event, in the order they happened.\n"
        "  CALL   caller -> callee   : caller called callee\n"
        "  RETURN caller <- callee   : callee finished and returned to caller\n"
        "Time is microseconds since profiler_init(). incl = inclusive time,\n"
        "excl = exclusive time (own code only) of that single call.\n"
        "ROOT means the call came from outside instrumented code.\n\n");

    fprintf(P.f_trace,
        "CALL TRACE\n"
        "==========\n"
        "Indented enter/exit trace of the whole run (indent = call depth).\n\n");

    P.t0 = raw_us();
    P.on = 1;
    printf("[Profiler] started\n");
}

void profiler_func_entry(const char *func_name)
{
    if (!P.on) return;

    if (P.sp >= PROF_MAX_DEPTH) {        /* matching exit is skipped as well */
        P.too_deep++;
        if (P.too_deep == 1)
            warn("call stack deeper than PROF_MAX_DEPTH at %s()%s", func_name, "");
        return;
    }

    double t = now_us();               /* start of profiler work for this call */
    const char *caller = (P.sp > 0) ? P.stack[P.sp - 1].func : "ROOT";
    int parent_path    = (P.sp > 0) ? P.stack[P.sp - 1].path : -1;
    int path = (parent_path >= 0 || P.sp == 0) ? path_get(parent_path, func_name) : -1;

    if (path >= 0) P.paths[path].count++;
    pair_add(caller, func_name);
    FuncRecord *fn = func_get(func_name);
    if (fn) fn->calls++;
    P.n_calls++;

    indent(P.f_trace, P.sp);
    fprintf(P.f_trace, "-> ENTER %s()\n", func_name);
    fprintf(P.f_events, "[%12.2f us] CALL   %-13s -> %-13s path %d\n",
            t, caller, func_name, path);
    P.n_events++;

    Frame *fr   = &P.stack[P.sp++];
    fr->func     = func_name;
    fr->path     = path;
    fr->child_us = 0.0;
    /* timestamp taken last, so the logging above is not counted
       as part of this function's own time */
    fr->t_enter  = now_us();

    /* the bookkeeping above is profiler overhead: keep it out of the
       caller's exclusive time and report it separately instead */
    double ovh = fr->t_enter - t;
    P.overhead_us += ovh;
    if (P.sp > 1) P.stack[P.sp - 2].child_us += ovh;
}

void profiler_func_exit(const char *func_name)
{
    if (!P.on) return;
    double t = now_us();               /* taken first, before any bookkeeping */

    if (P.too_deep > 0) { P.too_deep--; return; }

    if (P.sp == 0) {
        warn("FUNC_EXIT() in %s() with nothing on the stack%s", func_name, "");
        return;
    }

    if (strcmp(P.stack[P.sp - 1].func, func_name) != 0) {
        /* a FUNC_EXIT() was forgotten somewhere (e.g. an early return).
           If func_name is further down the stack, close the frames above it. */
        int k = P.sp - 1;
        while (k >= 0 && strcmp(P.stack[k].func, func_name) != 0) k--;
        if (k < 0) {
            warn("FUNC_EXIT() in %s() but %s() is on top of the stack, ignored",
                 func_name, P.stack[P.sp - 1].func);
            return;
        }
        warn("%s() returned without FUNC_EXIT(), closed when %s() exited",
             P.stack[P.sp - 1].func, func_name);
        while (P.sp - 1 > k) pop_frame(t);
    }

    pop_frame(t);

    double ovh = now_us() - t;         /* same idea as in profiler_func_entry */
    P.overhead_us += ovh;
    if (P.sp > 0) P.stack[P.sp - 1].child_us += ovh;
}

/* ------------------------------------------------------------------ */
/* report writing                                                      */
/* ------------------------------------------------------------------ */

static void write_cct(FILE *f, int parent)
{
    int i;
    for (i = 0; i < P.n_paths; i++) {
        PathRecord *p = &P.paths[i];
        if (p->parent != parent) continue;
        indent(f, p->depth);
        fprintf(f, "%s  x%ld   incl %.2f us   excl %.2f us\n",
                p->func, p->count, p->incl_us, p->excl_us);
        write_cct(f, i);
    }
}

/* path table rows in tree order (each path followed by its extensions) */
static void write_path_rows(FILE *f, int parent, int *row)
{
    int i;
    for (i = 0; i < P.n_paths; i++) {
        PathRecord *p = &P.paths[i];
        if (p->parent != parent) continue;
        fprintf(f, "%4d %8ld %13.2f %11.3f %13.2f   %s\n",
                (*row)++, p->count, p->incl_us,
                p->count ? p->incl_us / p->count : 0.0,
                p->excl_us, p->text);
        write_path_rows(f, i, row);
    }
}

static int cmp_excl_desc(const void *a, const void *b)
{
    double x = ((const FuncRecord *)a)->excl_us, y = ((const FuncRecord *)b)->excl_us;
    return (x < y) - (x > y);
}

void profiler_finish(void)
{
    int i;
    if (!P.on) return;

    /* close anything still open (should be nothing if main has FUNC_EXIT()) */
    if (P.sp > 0) {
        warn("%s() still open at profiler_finish(), closing it%s",
             P.stack[P.sp - 1].func, "");
        double t = now_us();
        while (P.sp > 0) pop_frame(t);
    }
    P.t_end = now_us();

    /* ---------------- event log summary ---------------- */
    fprintf(P.f_events,
        "\nCALL RELATIONSHIP SUMMARY (which function called which)\n"
        "========================================================\n"
        "%-12s    %-12s %8s\n", "caller", "callee", "times");
    for (i = 0; i < P.n_pairs; i++)
        fprintf(P.f_events, "%-12s -> %-12s %8ld\n",
                P.pairs[i].caller, P.pairs[i].callee, P.pairs[i].count);
    fprintf(P.f_events,
        "\nDistinct caller -> callee pairs : %d\n"
        "Function calls                  : %ld\n"
        "Events written (CALL + RETURN)  : %ld\n"
        "Warnings                        : %d\n"
        "Total profiled time             : %.2f us\n"
        "  of which profiler overhead    : %.2f us\n",
        P.n_pairs, P.n_calls, P.n_events, P.n_warnings, P.t_end, P.overhead_us);

    /* ---------------- path profiles ---------------- */
    FILE *f = fopen("path_profiles.txt", "w");
    if (!f) {
        fprintf(stderr, "[Profiler] could not write path_profiles.txt\n");
    } else {
        fprintf(f,
            "PATH PROFILES\n"
            "=============\n"
            "Each row is one distinct call path, i.e. one chain of calls starting\n"
            "at main. Count is how many times that exact path was executed.\n"
            "Times are in microseconds, added over every execution of the path:\n"
            "  inclusive = from entering the last function to leaving it,\n"
            "              including everything it called\n"
            "  exclusive = inclusive minus time spent in the functions it called\n"
            "              (and minus the profiler's own logging time)\n\n");

        fprintf(f, "%4s %8s %13s %11s %13s   %s\n",
                "ID", "count", "incl total", "incl avg", "excl total", "path");
        fprintf(f, "%4s %8s %13s %11s %13s   %s\n",
                "--", "-----", "----------", "--------", "----------", "----");
        int row = 0;
        write_path_rows(f, -1, &row);
        fprintf(f, "\nDistinct paths: %d\n", P.n_paths);

        fprintf(f,
            "\n\nCALLING CONTEXT TREE\n"
            "====================\n"
            "Same data drawn as a tree. xN = times executed in that context.\n\n");
        write_cct(f, -1);

        FuncRecord sorted[PROF_MAX_FUNCS];
        memcpy(sorted, P.funcs, sizeof(FuncRecord) * (size_t)P.n_funcs);
        qsort(sorted, (size_t)P.n_funcs, sizeof sorted[0], cmp_excl_desc);

        double excl_sum = 0.0;
        for (i = 0; i < P.n_funcs; i++) excl_sum += sorted[i].excl_us;

        fprintf(f,
            "\n\nPER-FUNCTION SUMMARY (all paths added together, by exclusive time)\n"
            "==================================================================\n");
        fprintf(f, "%-12s %8s %13s %13s %11s %8s\n",
                "function", "calls", "incl total", "excl total", "excl avg", "excl %");
        for (i = 0; i < P.n_funcs; i++) {
            FuncRecord *r = &sorted[i];
            fprintf(f, "%-12s %8ld %13.2f %13.2f %11.3f %7.1f%%\n",
                    r->name, r->calls, r->incl_us, r->excl_us,
                    r->calls ? r->excl_us / r->calls : 0.0,
                    excl_sum > 0 ? 100.0 * r->excl_us / excl_sum : 0.0);
        }

        fprintf(f,
            "\nFunction calls      : %ld\n"
            "Total profiled time : %.2f us\n"
            "Profiler overhead   : %.2f us (logging done by FUNC_ENTRY/FUNC_EXIT;\n"
            "                      it is inside inclusive times but has been taken\n"
            "                      out of every exclusive time)\n"
            "Warnings            : %d\n",
            P.n_calls, P.t_end, P.overhead_us, P.n_warnings);
        fclose(f);
    }

    fprintf(P.f_trace, "\nFunction calls: %ld, total profiled time: %.2f us\n",
            P.n_calls, P.t_end);
    fclose(P.f_events);
    fclose(P.f_trace);
    P.on = 0;

    printf("[Profiler] finished: %ld calls, %d distinct paths, %.2f us\n",
           P.n_calls, P.n_paths, P.t_end);
    printf("[Profiler] wrote path_profiles.txt, event_log.txt, call_trace.txt\n");
}
