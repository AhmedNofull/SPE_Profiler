/*
 * profiler.h - instrumentation profiler for C programs
 *
 * Software Performance Evaluation (CSE433) - Major Assignment, Fall 2026
 *
 * How to use it:
 *   1. #include "profiler.h" in the program you want to measure
 *   2. call profiler_init() as the first statement of main()
 *   3. put FUNC_ENTRY() as the first statement of every function (main too)
 *   4. put FUNC_EXIT() just before every return / end of every function
 *   5. call profiler_finish() at the end of main(), after main's FUNC_EXIT()
 *
 * Running the program then writes three text files in the current folder:
 *   path_profiles.txt  every distinct call path with how many times it ran,
 *                      its inclusive and exclusive time, the calling context
 *                      tree, and a per-function summary
 *   event_log.txt      every CALL / RETURN event in order (who called whom,
 *                      with timestamps), then a caller -> callee summary
 *   call_trace.txt     the same run as an indented enter/exit trace
 *
 * Recursion and C++ member functions are out of scope for this assignment.
 */

#ifndef PROFILER_H
#define PROFILER_H

/* Size limits. Paths and pairs are stored once each, however many times
 * they run, so these only limit how many *different* ones a program has. */
#define PROF_MAX_DEPTH   64    /* deepest call chain that is tracked        */
#define PROF_MAX_PATHS   512   /* distinct call paths                       */
#define PROF_MAX_PAIRS   256   /* distinct caller -> callee pairs           */
#define PROF_MAX_FUNCS   128   /* distinct functions                        */
#define PROF_PATH_LEN    512   /* longest path string, e.g. "main -> f1 -> square" */

void profiler_init(void);
void profiler_finish(void);
void profiler_func_entry(const char *func_name);
void profiler_func_exit(const char *func_name);

/* __func__ is the C99 name of the enclosing function */
#define FUNC_ENTRY() profiler_func_entry(__func__)
#define FUNC_EXIT()  profiler_func_exit(__func__)

#endif /* PROFILER_H */
