@echo off
REM build.bat - Windows (MinGW-w64 / MSYS2 gcc must be on PATH)
REM Builds the three test programs and runs them.
REM Outputs go to output\<program>\

where gcc >nul 2>nul
if errorlevel 1 (
    echo gcc not found. Install MinGW-w64 or MSYS2 and add it to PATH.
    if not "%1"=="nopause" pause
    exit /b 1
)

for %%P in (doctor_program example_program grades_program) do (
    echo Building %%P ...
    gcc -std=c99 -Wall -Wextra -O2 -Isrc -o %%P.exe tests\%%P.c src\profiler.c
    if errorlevel 1 ( echo Build of %%P failed & exit /b 1 )
)

if not exist output\doctor_program  mkdir output\doctor_program
if not exist output\example_program mkdir output\example_program
if not exist output\grades_program  mkdir output\grades_program

pushd output\doctor_program  & ..\..\doctor_program.exe  > console_output.txt & popd
pushd output\example_program & ..\..\example_program.exe > console_output.txt & popd
pushd output\grades_program  & ..\..\grades_program.exe ..\..\tests\scores.txt > console_output.txt & popd

echo.
echo Done. Results are in the output folder.
if not "%1"=="nopause" pause
