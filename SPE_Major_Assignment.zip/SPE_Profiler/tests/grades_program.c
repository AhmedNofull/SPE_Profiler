/*
 * grades_program.c - a second, more "real" test program.
 *
 * Reads student scores from an input text file (scores.txt by default,
 * or the file given on the command line), computes some statistics and
 * prints a small report.
 *
 * Things it exercises that the other tests do not:
 *   - early returns (each one has its own FUNC_EXIT before it)
 *   - the same function reached through different paths:
 *       mean() is called from compute_stats() and from std_dev()
 *       letter_grade() is called from print_report() and count_passed()
 *   - a deeper chain: main -> compute_stats -> std_dev -> mean
 *
 * Input file format: one student per line, "name score" (score 0-100).
 * Lines starting with # are comments.
 */

#include <stdio.h>
#include <string.h>
#include "profiler.h"

#define MAX_STUDENTS 100

typedef struct {
    char name[32];
    int  score;
} Student;

static Student students[MAX_STUDENTS];
static int     n_students = 0;

/* returns 1 if the line held a valid student, 0 otherwise */
int parse_line(const char *line, Student *out)
{
    FUNC_ENTRY();

    if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') {
        FUNC_EXIT();
        return 0;
    }
    if (sscanf(line, "%31s %d", out->name, &out->score) != 2) {
        FUNC_EXIT();
        return 0;
    }
    if (out->score < 0 || out->score > 100) {
        FUNC_EXIT();
        return 0;
    }

    FUNC_EXIT();
    return 1;
}

int read_scores(const char *filename)
{
    FUNC_ENTRY();

    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("cannot open %s\n", filename);
        FUNC_EXIT();
        return 0;
    }

    char line[128];
    int skipped = 0;
    while (fgets(line, sizeof line, f) && n_students < MAX_STUDENTS) {
        if (parse_line(line, &students[n_students]))
            n_students++;
        else
            skipped++;
    }
    fclose(f);
    printf("read %d students (%d lines skipped)\n", n_students, skipped);

    FUNC_EXIT();
    return n_students;
}

double mean(void)
{
    FUNC_ENTRY();
    double sum = 0;
    for (int i = 0; i < n_students; i++)
        sum += students[i].score;
    FUNC_EXIT();
    return n_students ? sum / n_students : 0.0;
}

/* simple square root (Newton's method) so we do not need -lm */
double my_sqrt(double x)
{
    FUNC_ENTRY();
    if (x <= 0) {
        FUNC_EXIT();
        return 0;
    }
    double g = x;
    for (int i = 0; i < 30; i++)
        g = 0.5 * (g + x / g);
    FUNC_EXIT();
    return g;
}

double std_dev(void)
{
    FUNC_ENTRY();
    double m = mean();
    double acc = 0;
    for (int i = 0; i < n_students; i++) {
        double d = students[i].score - m;
        acc += d * d;
    }
    double s = my_sqrt(n_students ? acc / n_students : 0.0);
    FUNC_EXIT();
    return s;
}

char letter_grade(int score)
{
    FUNC_ENTRY();
    char g;
    if (score >= 85)      g = 'A';
    else if (score >= 75) g = 'B';
    else if (score >= 65) g = 'C';
    else if (score >= 50) g = 'D';
    else                  g = 'F';
    FUNC_EXIT();
    return g;
}

int count_passed(void)
{
    FUNC_ENTRY();
    int passed = 0;
    for (int i = 0; i < n_students; i++)
        if (letter_grade(students[i].score) != 'F')
            passed++;
    FUNC_EXIT();
    return passed;
}

void compute_stats(void)
{
    FUNC_ENTRY();
    double m = mean();
    double s = std_dev();
    int p = count_passed();
    printf("mean %.2f, std dev %.2f, passed %d of %d\n", m, s, p, n_students);
    FUNC_EXIT();
}

void print_report(void)
{
    FUNC_ENTRY();
    printf("\n%-12s %5s %5s\n", "name", "score", "grade");
    for (int i = 0; i < n_students; i++)
        printf("%-12s %5d %5c\n", students[i].name, students[i].score,
               letter_grade(students[i].score));
    FUNC_EXIT();
}

int main(int argc, char **argv)
{
    profiler_init();
    FUNC_ENTRY();

    const char *file = (argc > 1) ? argv[1] : "scores.txt";
    if (read_scores(file) == 0) {
        FUNC_EXIT();
        profiler_finish();
        return 1;
    }
    compute_stats();
    print_report();

    FUNC_EXIT();
    profiler_finish();
    return 0;
}
