/*
 * example_program.c - Example program demonstrating the profiler
 * 
 * This program contains multiple functions calling each other
 * to demonstrate the instrumentation and profiling capabilities.
 * 
 * Call hierarchy:
 *   main()
 *     |-> functionA()
 *     |     |-> functionC()
 *     |
 *     |-> functionB()
 *           |-> functionC()
 *           |-> functionD()
 *                 |-> functionE()
 */

#include <stdio.h>
#include "profiler.h"

/* Forward declarations */
void functionA(void);
void functionB(void);
void functionC(void);
void functionD(void);
void functionE(void);

/*
 * functionE - Leaf function (deepest in call chain)
 * Performs a simple computation
 */
void functionE(void) {
    FUNC_ENTRY();
    
    printf("  [functionE] Performing deep computation...\n");
    
    /* Simulate some work */
    volatile int sum = 0;
    for (int i = 0; i < 50000; i++) {
        sum += i;
    }
    
    FUNC_EXIT();
}

/*
 * functionD - Intermediate function
 * Calls functionE
 */
void functionD(void) {
    FUNC_ENTRY();
    
    printf("  [functionD] Processing data...\n");
    
    /* Simulate some work */
    volatile int product = 1;
    for (int i = 1; i < 100; i++) {
        product *= i % 10 + 1;
    }
    
    /* Call deeper function */
    functionE();
    
    FUNC_EXIT();
}

/*
 * functionC - Shared function (called by both A and B)
 * A leaf function that doesn't call others
 */
void functionC(void) {
    FUNC_ENTRY();
    
    printf("  [functionC] Executing shared logic...\n");
    
    /* Simulate some work */
    volatile double result = 0.0;
    for (int i = 0; i < 30000; i++) {
        result += i * 0.001;
    }
    
    FUNC_EXIT();
}

/*
 * functionB - Branch B from main
 * Calls functionC and functionD
 */
void functionB(void) {
    FUNC_ENTRY();
    
    printf("  [functionB] Starting branch B operations...\n");
    
    /* Simulate initial work */
    volatile int count = 0;
    for (int i = 0; i < 20000; i++) {
        count++;
    }
    
    /* Call two functions */
    functionC();
    functionD();
    
    printf("  [functionB] Completed branch B\n");
    
    FUNC_EXIT();
}

/*
 * functionA - Branch A from main
 * Calls functionC
 */
void functionA(void) {
    FUNC_ENTRY();
    
    printf("  [functionA] Starting branch A operations...\n");
    
    /* Simulate some work */
    volatile int value = 0;
    for (int i = 0; i < 40000; i++) {
        value += i % 7;
    }
    
    /* Call shared function */
    functionC();
    
    printf("  [functionA] Completed branch A\n");
    
    FUNC_EXIT();
}

/*
 * Main entry point
 */
int main(void) {
    printf("========================================\n");
    printf("  Function Profiler Demo Program\n");
    printf("========================================\n\n");
    
    /* Initialize the profiler */
    profiler_init();
    
    FUNC_ENTRY();
    
    printf("[main] Starting program execution...\n\n");
    
    /* Execute branch A */
    printf("[main] Calling functionA (Branch A)...\n");
    functionA();
    printf("\n");
    
    /* Execute branch B */
    printf("[main] Calling functionB (Branch B)...\n");
    functionB();
    printf("\n");
    
    printf("[main] Program execution complete.\n\n");
    
    FUNC_EXIT();
    
    /* Finalize profiler and write output files */
    profiler_finish();
    
    printf("\n========================================\n");
    printf("  Demo Complete - Check output files!\n");
    printf("========================================\n");
    
    return 0;
}
