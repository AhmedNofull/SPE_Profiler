/*
 * doctor_program.c - the square / cube / f1 / f2 example from the lecture
 * sheet (sheet3.xlsx, "C Code For Path Profiling"), rewritten in C.
 *
 * The lecture version counted paths by hand with a global register r
 * (r += 1 in f1, r += 2 in f2, r += 4 in cube) and expected:
 *
 *   main -> square            148
 *   main -> f1 -> square      245
 *   main -> f2 -> square      215
 *   main -> cube               99
 *   main -> f1 -> cube        245
 *   main -> f2 -> cube        430
 *
 * Here the hand-written counters are replaced by FUNC_ENTRY / FUNC_EXIT,
 * and the profiler has to find the same numbers on its own.
 */

#include <stdio.h>
#include "profiler.h"

int square(int x);
int cube(int x);
int f1(int a, int b);
int f2(int a, int b);

int square(int x)
{
    FUNC_ENTRY();
    int r = x * x;
    FUNC_EXIT();
    return r;
}

int cube(int x)
{
    FUNC_ENTRY();
    int r = x * x * x;
    FUNC_EXIT();
    return r;
}

int f1(int a, int b)
{
    FUNC_ENTRY();
    (void)a; (void)b;
    for (int i = 1; i <= 5; i++) {
        int s1 = square(i);
        int c1 = cube(i);
        printf("%d ", s1 + c1);
    }
    printf("\n");
    FUNC_EXIT();
    return 0;
}

int f2(int a, int b)
{
    FUNC_ENTRY();
    (void)a; (void)b;
    for (int i = 1; i <= 5; i++) {
        int s1 = square(i);
        int c1 = cube(i);
        int c2 = cube(i);
        printf("%d ", s1 + c1 + c2);
    }
    printf("\n");
    FUNC_EXIT();
    return 0;
}

int main(void)
{
    profiler_init();
    FUNC_ENTRY();

    for (int i = 1; i < 100; i++) {
        int s = square(i);
        printf("%d %d", i, s);
        int c = cube(i);
        printf(" %d\n", c);
    }

    for (int i = 1; i < 50; i++) {
        int s = square(i);
        printf("%d %d\n", i, s);
    }

    for (int j = 1; j < 50; j++) {
        f1(j, j + 1);
        if (j > 6)
            f2(j, j + 1);
    }

    FUNC_EXIT();
    profiler_finish();
    return 0;
}
