#!/usr/bin/env python3
"""
evaluate.py - build the test programs, run them, and check the results.

What it does:
  1. compiles doctor_program, grades_program and example_program with gcc
  2. runs each one in results/output/<program>/ (grades_program reads tests/scores.txt);
     output/ itself is left alone, because it holds the run shown in the report
  3. checks the path counts of doctor_program against the lecture sheet
     (148, 245, 215, 99, 245, 430) and stops with an error if any differ
  4. runs doctor_program --runs more times in a scratch folder and records the
     total time, profiler overhead and per-path counts of every run
  5. optionally runs grades_program on a generated input (--generated N)
  6. writes the timing table to results/evaluation.csv and prints a short summary

Usage (from the repository root):
    python scripts/evaluate.py
    python scripts/evaluate.py --runs 10 --generated 90
Requires gcc on PATH (MinGW-w64 / MSYS2 on Windows) and Python 3.
"""
import argparse
import csv
import os
import platform
import re
import shutil
import statistics
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = ".exe" if os.name == "nt" else ""
PROGRAMS = ["doctor_program", "grades_program", "example_program"]
LECTURE = {
    "main -> square": 148,
    "main -> f1 -> square": 245,
    "main -> f2 -> square": 215,
    "main -> cube": 99,
    "main -> f1 -> cube": 245,
    "main -> f2 -> cube": 430,
}


def build(name):
    out = os.path.join(ROOT, name + EXE)
    cmd = ["gcc", "-std=c99", "-Wall", "-Wextra", "-O2", "-I" + os.path.join(ROOT, "src"),
           "-o", out, os.path.join(ROOT, "tests", name + ".c"), os.path.join(ROOT, "src", "profiler.c")]
    subprocess.run(cmd, check=True)
    return out


def run(exe, workdir, args=()):
    os.makedirs(workdir, exist_ok=True)
    with open(os.path.join(workdir, "console_output.txt"), "w") as con:
        subprocess.run([exe, *args], cwd=workdir, stdout=con, check=True)


def read_profile(workdir):
    with open(os.path.join(workdir, "path_profiles.txt")) as f:
        text = f.read().replace("\r", "")
    paths = {}
    for line in text.split("\n"):
        m = re.match(r"\s*\d+\s+(\d+)\s+([\d.]+)\s+[\d.]+\s+([\d.]+)\s+(main.*)$", line)
        if m:
            paths[m.group(4).strip()] = (int(m.group(1)), float(m.group(2)), float(m.group(3)))
    total = float(re.search(r"Total profiled time : ([\d.]+)", text).group(1))
    overhead = float(re.search(r"Profiler overhead   : ([\d.]+)", text).group(1))
    warnings = int(re.search(r"Warnings\s+: (\d+)", text).group(1))
    return paths, total, overhead, warnings


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=5, help="extra timing runs of doctor_program")
    ap.add_argument("--generated", type=int, default=0,
                    help="also run grades_program on N generated students (0 = skip)")
    args = ap.parse_args()

    if shutil.which("gcc") is None:
        sys.exit("gcc not found on PATH")

    print("Building ...")
    exes = {p: build(p) for p in PROGRAMS}

    print("Running the three test programs ...")
    res = os.path.join(ROOT, "results", "output")
    run(exes["doctor_program"], os.path.join(res, "doctor_program"))
    run(exes["example_program"], os.path.join(res, "example_program"))
    run(exes["grades_program"], os.path.join(res, "grades_program"),
        [os.path.join(ROOT, "tests", "scores.txt")])

    paths, total, overhead, warnings = read_profile(os.path.join(res, "doctor_program"))
    print("\nPath counts of doctor_program vs the lecture sheet:")
    ok = True
    for p, expected in LECTURE.items():
        got = paths.get(p, (None,))[0]
        status = "OK" if got == expected else "MISMATCH"
        ok &= got == expected
        print("  %-24s expected %4d  got %4s  %s" % (p, expected, got, status))
    if warnings:
        print("  profiler reported %d warnings" % warnings)
        ok = False

    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for i in range(args.runs):
            d = os.path.join(tmp, "run%d" % i)
            run(exes["doctor_program"], d)
            pr, t, o, w = read_profile(d)
            same = all(pr.get(p, (None,))[0] == n for p, n in LECTURE.items())
            ok &= same and w == 0
            rows.append({"program": "doctor_program", "run": i + 1, "total_us": t, "overhead_us": o,
                         "program_us": round(t - o, 2), "overhead_pct": round(100 * o / t, 1),
                         "counts_match_lecture": same, "warnings": w})

        if args.generated:
            gen = os.path.join(tmp, "generated_scores.txt")
            subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "gen_scores.py"),
                            "-n", str(args.generated), "-o", gen], check=True)
            d = os.path.join(tmp, "grades_generated")
            run(exes["grades_program"], d, [gen])
            pr, t, o, w = read_profile(d)
            parse = [v for k, v in pr.items() if k.endswith("parse_line")][0][0]
            rows.append({"program": "grades_program (generated %d)" % args.generated, "run": 1,
                         "total_us": t, "overhead_us": o, "program_us": round(t - o, 2),
                         "overhead_pct": round(100 * o / t, 1),
                         "counts_match_lecture": "", "warnings": w})
            print("\nGenerated input: parse_line ran %d times (one per input line)" % parse)

    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    out_csv = os.path.join(ROOT, "results", "evaluation.csv")
    with open(out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else ["program"])
        w.writeheader()
        w.writerows(rows)

    doc = [r for r in rows if r["program"] == "doctor_program"]
    if doc:
        tt = [r["total_us"] for r in doc]
        pp = [r["overhead_pct"] for r in doc]
        print("\n%d timing runs of doctor_program on %s:" % (len(doc), platform.platform()))
        print("  total time   : min %.1f  median %.1f  max %.1f us" % (min(tt), statistics.median(tt), max(tt)))
        print("  overhead     : median %.1f %% of the run" % statistics.median(pp))
        print("  counts       : identical in every run" if all(r["counts_match_lecture"] for r in doc)
              else "  counts       : DIFFERENT in some runs")
    print("\nResults written to %s" % os.path.relpath(out_csv, ROOT))
    print("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
