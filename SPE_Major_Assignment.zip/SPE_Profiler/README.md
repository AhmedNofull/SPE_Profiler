# Path profiler for C programs

CSE433: Software Performance Evaluation (Fall 2026), CSE446 (UG2023) - Software Performance Evaluation
Ain Shams University, Faculty of Engineering, Computer and Systems Engineering Department
Major assignment, submitted to Dr. Islam El-Maddah

| Name | ID |
|------|----|
| Karim Samer Mostafa Ragab | 23P0439 |
| Omar Gamil Anwar Osman | 23P0438 |
| Youssef Maged Morees Ageb Farag | 2301081 |
| Mohamed Amir Kamal | 2301144 |
| Ahmed Abdallah Hassan Ahmed Nofull | 22P0255 |

You add two macros, `FUNC_ENTRY()` and `FUNC_EXIT()`, to every function of a C program. When the
program runs, the profiler writes three text files:

- `path_profiles.txt` lists every distinct call path (for example `main -> f1 -> square`), how many
  times it ran, and its inclusive and exclusive time. It also has the calling context tree and a
  summary for each function.
- `event_log.txt` has one line for every call and every return, in order, followed by a table of
  which function called which and how many times.
- `call_trace.txt` shows the same run as an indented enter/exit trace.

Repository: https://github.com/AhmedNofull/SPE_Profiler

The full write-up, with screenshots of a real run, is in [`report/SPE_Report.pdf`](report/SPE_Report.pdf).

## What is in the repository

```
src/profiler.h, src/profiler.c   the profiler (the instrumentation code)
tests/doctor_program.c           the square/cube/f1/f2 program from the lecture sheet
tests/grades_program.c           reads a scores file; has early returns and a 4-level path
tests/example_program.c          small five-function demo
tests/scores.txt                 input file used for the run in the report
scripts/gen_scores.py            input generation: makes new scores files for grades_program
scripts/evaluate.py              performance evaluation: builds, runs, checks counts, repeats timing runs
build.bat                        Windows: build all three tests and run them into output/
Makefile                         Linux / macOS: the same with `make run`
output/<program>/                the outputs of the run shown in the report (Windows, VS Code, MSYS2 gcc)
report/SPE_Report.pdf            the report
```

## Requirements

- gcc with C99 support. On Windows we used MSYS2 (UCRT64), and MinGW-w64 also works. On Linux or
  macOS, use the system gcc or clang.
- Python 3, needed only for the two scripts in `scripts/`. They use only the standard library.

Check that both are on your PATH:

```
gcc --version
python --version
```

## Reproducing our results

### 1. Get the code

```
git clone https://github.com/AhmedNofull/SPE_Profiler.git
cd SPE_Profiler
```

### 2. Build and run the three test programs

Windows:

```
build.bat
```

Linux / macOS:

```
make run
```

Each program runs in its own folder under `output/` and writes `path_profiles.txt`, `event_log.txt`,
`call_trace.txt` and `console_output.txt` there. This is exactly how the files in the report were
produced. Your counts will be the same as ours, but your times will be different.

To build and run a single program by hand:

```
gcc -std=c99 -Wall -Wextra -O2 -Isrc tests/doctor_program.c src/profiler.c -o doctor_program
./doctor_program            (on Windows: doctor_program.exe)
```

### 3. Run the performance evaluation

```
python scripts/evaluate.py --runs 5 --generated 90
```

This script:

1. compiles the three test programs
2. runs them into `results/output/`, leaving `output/` untouched
3. checks the path counts of `doctor_program` against the lecture sheet (148, 245, 215, 99, 245, 430)
4. runs `doctor_program` five more times and records the total time, the profiler overhead and the
   time left for the program itself on each run
5. generates a 90-student input file and runs `grades_program` on it
6. writes the timing table to `results/evaluation.csv`

It prints `ALL CHECKS PASSED` and exits with code 0 when every count matches and there are no
warnings.

### 4. Generate your own inputs

```
python scripts/gen_scores.py -n 60 --seed 7 -o tests/my_scores.txt
grades_program tests/my_scores.txt
```

By default the generator also adds a few lines the program has to reject (a comment, an
out-of-range score and a malformed line), so the early returns in `parse_line()` are tested.
`--clean` leaves those lines out. The same seed always produces the same file. `grades_program`
holds at most 100 students.

## Using the profiler on your own program

```c
#include "profiler.h"

int helper(int x)
{
    FUNC_ENTRY();
    if (x < 0) {
        FUNC_EXIT();          /* every return needs one */
        return 0;
    }
    int r = x * 2;
    FUNC_EXIT();
    return r;
}

int main(void)
{
    profiler_init();          /* first line of main */
    FUNC_ENTRY();
    helper(5);
    FUNC_EXIT();
    profiler_finish();        /* writes the files */
    return 0;
}
```

Compile your file together with `src/profiler.c` and `-Isrc`. If you forget a `FUNC_EXIT()` before
a return, the profiler prints a warning and closes that call when its caller exits, so the rest of
the results stay correct.

## Limits

Recursive functions and C++ member functions are out of scope, as the assignment allows. The
program must be single-threaded. The profiler handles up to 512 distinct paths and a call depth of
64 (both set in `profiler.h`), and it prints a warning if either limit is reached. The number of
calls is not limited.
